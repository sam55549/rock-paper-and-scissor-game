import random
def get_computer_choice(valid_choices):
    return random.choice(valid_choices)
   


